# GitHub workflow 설치

ZIP에는 숨김 파일을 넣지 않기 위해 workflow 원본을 `github/workflows/`에 넣었습니다.

GitHub 저장소에서는 반드시 다음처럼 이동/생성하세요.

- `github/workflows/update.yml` → `.github/workflows/update.yml`
- `github/workflows/pages.yml` → `.github/workflows/pages.yml`

`.github`는 GitHub Actions가 인식하는 공식 workflow 경로입니다.
