import io, os, zipfile, requests, xml.etree.ElementTree as ET
from pathlib import Path
from dotenv import load_dotenv
load_dotenv()
BASE="https://opendart.fss.or.kr/api"
class DartError(RuntimeError): pass
class DartClient:
    def __init__(self, api_key=None, cache_dir="data/raw"):
        self.api_key=api_key or os.getenv("DART_API_KEY")
        if not self.api_key or self.api_key.startswith("YOUR_"): raise DartError("DART_API_KEY가 설정되지 않았습니다.")
        self.cache_dir=Path(cache_dir); self.cache_dir.mkdir(parents=True,exist_ok=True)
    def get_json(self, endpoint, params):
        r=requests.get(f"{BASE}/{endpoint}.json",params={"crtfc_key":self.api_key,**params},timeout=60); r.raise_for_status()
        data=r.json()
        if data.get("status")!="000": raise DartError(f"{endpoint}: {data.get('status')} {data.get('message')}")
        return data
    def download_corp_codes(self):
        r=requests.get(f"{BASE}/corpCode.xml",params={"crtfc_key":self.api_key},timeout=60); r.raise_for_status()
        with zipfile.ZipFile(io.BytesIO(r.content)) as z: return ET.fromstring(z.read("CORPCODE.xml"))
    def resolve_corp_code(self, company_name):
        import pandas as pd
        cache=self.cache_dir/"corp_codes.csv"
        if cache.exists(): df=pd.read_csv(cache,dtype=str).fillna("")
        else:
            rows=[]
            for x in self.download_corp_codes().findall("list"):
                rows.append({"corp_code":x.findtext("corp_code","") ,"corp_name":x.findtext("corp_name","") ,"stock_code":x.findtext("stock_code","") ,"modify_date":x.findtext("modify_date","")})
            df=pd.DataFrame(rows); df.to_csv(cache,index=False,encoding="utf-8-sig")
        exact=df[df.corp_name.eq(company_name)]
        if len(exact)==1: return exact.iloc[0].to_dict()
        partial=df[df.corp_name.str.contains(company_name,na=False)]
        if len(partial)==1: return partial.iloc[0].to_dict()
        raise DartError(f"회사명을 정확히 찾지 못했습니다: {company_name}. DART_CORP_CODE를 지정하세요.")
    def financials(self, corp_code, year, reprt_code):
        return self.get_json("fnlttSinglAcntAll",{"corp_code":corp_code,"bsns_year":str(year),"reprt_code":reprt_code,"fs_div":"CFS"})
