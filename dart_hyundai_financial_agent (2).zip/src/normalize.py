import re
KEYS={
"revenue":["매출액","영업수익","수익(매출액)","매출"],"operating_income":["영업이익","영업이익(손실)"],"net_income":["당기순이익","당기순이익(손실)","분기순이익","반기순이익"],"assets":["자산총계"],"liabilities":["부채총계"],"equity":["자본총계"],"cash":["현금및현금성자산","현금및현금성자산(현금성자산포함)"],"cfo":["영업활동현금흐름"],"cfi":["투자활동현금흐름"],"cff":["재무활동현금흐름"],"current_assets":["유동자산"],"current_liabilities":["유동부채"]}
def norm(s): return re.sub(r"\s+","",str(s)).lower()
def to_num(x):
    if x is None:return None
    s=str(x).replace(",","").strip()
    if s in ("","-","nan","None"):return None
    try:return float(s)
    except:return None
def choose(rows,aliases):
    aset={norm(a) for a in aliases}; c=[r for r in rows if norm(r.get("account_nm")) in aset]
    if not c:c=[r for r in rows if any(norm(a) in norm(r.get("account_nm")) for a in aliases)]
    return to_num(c[0].get("thstrm_amount")) if c else None
def extract_financials(api_json):
    rows=api_json.get("list",[]); return {k:choose(rows,a) for k,a in KEYS.items()}
def ratios(m):
    def pct(a,b): return None if a is None or b in (None,0) else a/b*100
    return {"operating_margin_pct":pct(m.get("operating_income"),m.get("revenue")),"net_margin_pct":pct(m.get("net_income"),m.get("revenue")),"roa_pct":pct(m.get("net_income"),m.get("assets")),"roe_pct":pct(m.get("net_income"),m.get("equity")),"debt_ratio_pct":pct(m.get("liabilities"),m.get("equity")),"equity_ratio_pct":pct(m.get("equity"),m.get("assets")),"current_ratio_pct":pct(m.get("current_assets"),m.get("current_liabilities")),"asset_turnover_x":None if not m.get("revenue") or not m.get("assets") else m["revenue"]/m["assets"]}
