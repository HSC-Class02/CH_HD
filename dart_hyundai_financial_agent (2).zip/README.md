# DART Hyundai Financial Analysis Agent

🔗 **[대시보드 바로가기](DASHBOARD_URL_PLACEHOLDER)**

OpenDART를 이용해 지정 기업의 사업보고서·반기보고서·분기보고서 재무정보를 수집하고, 주요 재무지표와 재무비율을 계산한 뒤 GitHub Pages 대시보드로 공개하는 프로젝트입니다.

## 대상 보고서
- 사업보고서
- 반기보고서
- 1분기보고서
- 3분기보고서

## 데이터 범위
OpenDART의 현재 정기보고서 재무 API는 **2015년 이후** 데이터를 제공합니다. 따라서 파이프라인은 2010년부터 실행을 시도하되, 2010~2014년은 `data/raw/unavailable_years.json`에 API 미제공 구간으로 기록하고, 2015년 이후는 자동 수집합니다.

## 주요 재무수치
매출액/영업수익, 영업이익, 당기순이익, 자산총계, 부채총계, 자본총계, 현금및현금성자산, 영업활동현금흐름, 투자활동현금흐름, 재무활동현금흐름, 유동자산, 유동부채

## 주요 재무비율
영업이익률, 순이익률, ROA, ROE, 부채비율, 자기자본비율, 유동비율, 총자산회전율, 매출/영업이익/순이익 성장률

## 실행
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy env.example .env
# .env에 DART_API_KEY 입력
python scripts/run_pipeline.py
```

## GitHub Actions
`github/workflows/`에 있는 워크플로 파일을 실제 GitHub 저장소의 `.github/workflows/`로 이동하세요. `update.yml`은 매월 1일 00:00 UTC(한국시간 09:00)에 실행되며 `workflow_dispatch`로 수동 실행도 가능합니다.

## API 키 입력
OpenDART에서 40자리 API 인증키를 발급한 뒤 GitHub Repository → Settings → Secrets and variables → Actions에서 `DART_API_KEY` Secret을 만드세요. API 키는 코드에 직접 넣지 않습니다.

## GitHub Pages
Repository → Settings → Pages → Source를 `GitHub Actions`로 설정합니다. 배포 후 `https://<USERNAME>.github.io/<REPOSITORY>/` 형태로 대시보드가 공개됩니다.

## Peer firms
`config/peers.csv`에 국내 비교기업을 관리하며 README/대시보드 하단에 표시합니다. 기본값은 현대자동차 기준의 국내 자동차 업종 예시입니다.

## 배지
`dashboard-badge.svg`를 README 최상단 링크에 사용할 수 있습니다. 사용자가 제공한 실제 배지 이미지가 프로젝트 폴더에 포함되지 않은 경우에도 SVG 배지는 동작합니다.
