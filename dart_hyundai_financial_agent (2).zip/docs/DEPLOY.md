# GitHub 배포

1. 새 GitHub repository를 만듭니다.
2. ZIP 압축을 풉니다.
3. `github/workflows/update.yml` → `.github/workflows/update.yml`로 이동합니다.
4. `github/workflows/pages.yml` → `.github/workflows/pages.yml`로 이동합니다.
5. Repository → Settings → Pages → Source를 `GitHub Actions`로 설정합니다.
6. `DART_API_KEY`를 Actions Secret으로 저장합니다.
7. Actions에서 `Deploy dashboard to GitHub Pages`를 실행합니다.
8. 이후 매월 1일에 DART 데이터가 갱신되고, dashboard 변경이 Pages에 배포됩니다.
9. Repository 우측 About → Website에 Pages URL을 입력합니다.
