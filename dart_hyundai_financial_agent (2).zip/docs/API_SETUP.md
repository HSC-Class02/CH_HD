# OpenDART API 설정

1. OpenDART에서 API 인증키를 발급합니다.
2. 로컬: `env.example`을 `.env`로 복사하고 `DART_API_KEY`를 입력합니다.
3. GitHub: Settings → Secrets and variables → Actions → New repository secret → 이름 `DART_API_KEY`.
4. 회사명은 Repository Variables의 `DART_COMPANY_NAME`, 또는 정확한 8자리 `DART_CORP_CODE`로 지정할 수 있습니다.
5. 회사명을 정확히 찾지 못하면 `data/raw/corp_codes.csv`를 확인해 corp_code를 지정합니다.
