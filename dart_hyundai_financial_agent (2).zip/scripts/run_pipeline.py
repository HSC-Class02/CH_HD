import os,json,sys
from pathlib import Path
import pandas as pd,yaml
from dotenv import load_dotenv
ROOT=Path(__file__).resolve().parents[1]; load_dotenv(ROOT/".env"); sys.path.insert(0,str(ROOT/"src"))
from dart_client import DartClient,DartError
from normalize import extract_financials,ratios

def main():
    cfg=yaml.safe_load((ROOT/"config/settings.yml").read_text(encoding="utf-8")); name=os.getenv("DART_COMPANY_NAME") or cfg["company"]["name"]; corp=os.getenv("DART_CORP_CODE") or cfg["company"].get("corp_code") or ""; c=DartClient(cache_dir=ROOT/"data/raw")
    if not corp: corp=c.resolve_corp_code(name)["corp_code"]
    end=int(cfg["period"]["end_year"] or pd.Timestamp.now().year); rows=[]; unavailable=[]
    for y in range(int(cfg["period"]["start_year"]),end+1):
      for period,code in cfg["period"]["report_codes"].items():
        if y<2015: unavailable.append({"year":y,"period":period,"reason":"OpenDART 정기보고서 재무 API 현재 제공범위 이전"}); continue
        try:
          data=c.financials(corp,y,code); (ROOT/"data/raw"/f"{y}_{period}.json").write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
          m=extract_financials(data); m.update({"year":y,"period":period,"corp_code":corp,"corp_name":name}); m.update(ratios(m)); rows.append(m)
        except DartError as e: rows.append({"year":y,"period":period,"corp_code":corp,"corp_name":name,"error":str(e)})
    df=pd.DataFrame(rows)
    for col in ["revenue","operating_income","net_income"]: df[col+"_growth_pct"]=df.groupby("period")[col].pct_change()*100
    proc=ROOT/"data/processed"; proc.mkdir(parents=True,exist_ok=True); df.to_csv(proc/"financials.csv",index=False,encoding="utf-8-sig")
    (ROOT/"data/raw/unavailable_years.json").write_text(json.dumps(unavailable,ensure_ascii=False,indent=2),encoding="utf-8")
    peers=pd.read_csv(ROOT/"config/peers.csv").to_dict(orient="records")
    payload={"company":{"name":name,"corp_code":corp},"updated_at":pd.Timestamp.utcnow().isoformat(),"coverage":{"requested_start":2010,"api_financial_start":2015},"records":df.where(pd.notna(df),None).to_dict(orient="records"),"peers":peers}
    (ROOT/"dashboard/data/metrics.json").write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding="utf-8")
    print("updated",name,corp,len(df))
if __name__=="__main__":main()
